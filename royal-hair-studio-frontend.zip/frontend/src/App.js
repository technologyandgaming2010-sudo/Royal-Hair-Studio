import "@/App.css";
import BusinessWebsite from "@/components/BusinessWebsite";

function App() {
  return <BusinessWebsite />;
}

export default App;
