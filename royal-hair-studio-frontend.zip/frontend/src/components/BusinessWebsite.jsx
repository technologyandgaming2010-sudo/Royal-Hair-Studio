import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import Lenis from "lenis";
import {
  Clock3,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  Scissors,
  Sparkles,
  WandSparkles,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Toaster, toast } from "@/components/ui/sonner";

const NAV_LINKS = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "services", label: "Services" },
  { id: "gallery", label: "Gallery" },
  { id: "contact", label: "Contact" },
];

const SERVICES = [
  {
    title: "Haircut",
    description:
      "Precision cuts tailored to your face shape and personal style.",
    icon: Scissors,
  },
  {
    title: "Hair Styling",
    description:
      "From classic looks to modern trends for work, parties, and events.",
    icon: Sparkles,
  },
  {
    title: "Beard Trim",
    description:
      "Clean beard shaping and detailing for a sharp, professional finish.",
    icon: WandSparkles,
  },
  {
    title: "Hair Spa",
    description:
      "Deep nourishment treatment to restore strength, shine, and texture.",
    icon: Clock3,
  },
];

const GALLERY_IMAGES = [
  {
    src: "https://images.pexels.com/photos/1813272/pexels-photo-1813272.jpeg?auto=compress&cs=tinysrgb&w=1400",
    alt: "Royal Hair Studio barber chair and interior",
  },
  {
    src: "https://images.pexels.com/photos/7697391/pexels-photo-7697391.jpeg?auto=compress&cs=tinysrgb&w=1200",
    alt: "Professional barber giving a haircut",
  },
  {
    src: "https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=1200",
    alt: "Men's grooming products on salon counter",
  },
  {
    src: "https://images.pexels.com/photos/3992874/pexels-photo-3992874.jpeg?auto=compress&cs=tinysrgb&w=1200",
    alt: "Stylish barber tools and grooming setup",
  },
  {
    src: "https://images.pexels.com/photos/1319461/pexels-photo-1319461.jpeg?auto=compress&cs=tinysrgb&w=1200",
    alt: "Modern men's salon station with mirror",
  },
  {
    src: "https://images.pexels.com/photos/2029624/pexels-photo-2029624.jpeg?auto=compress&cs=tinysrgb&w=1200",
    alt: "Barber at work with client in chair",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: [0.22, 1, 0.36, 1] },
  },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

export default function BusinessWebsite() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const lenis = new Lenis({ duration: 1.1, smoothWheel: true });
    let rafId;

    const raf = (time) => {
      lenis.raf(time);
      rafId = requestAnimationFrame(raf);
    };

    rafId = requestAnimationFrame(raf);
    return () => {
      cancelAnimationFrame(rafId);
      lenis.destroy();
    };
  }, []);

  const closeMobileMenu = () => setMobileMenuOpen(false);

  const onBookingClick = () => {
    toast.success("Booking request ready. Call or WhatsApp to confirm your slot.");
  };

  return (
    <div className="royal-site">
      <header className="royal-navbar">
        <div className="royal-container navbar-inner">
          <a href="#home" className="brand" onClick={closeMobileMenu}>
            Royal Hair Studio
          </a>

          <nav className="desktop-nav">
            {NAV_LINKS.map((link) => (
              <a key={link.id} href={`#${link.id}`} className="nav-link">
                {link.label}
              </a>
            ))}
          </nav>

          <Button
            className="mobile-menu-button"
            variant="ghost"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>

        {mobileMenuOpen && (
          <nav className="mobile-nav">
            {NAV_LINKS.map((link) => (
              <a
                key={link.id}
                href={`#${link.id}`}
                className="mobile-nav-link"
                onClick={closeMobileMenu}
              >
                {link.label}
              </a>
            ))}
          </nav>
        )}
      </header>

      <main>
        <section id="home" className="hero-section">
          <img
            src="https://images.pexels.com/photos/1813272/pexels-photo-1813272.jpeg?auto=compress&cs=tinysrgb&w=1800"
            alt="Royal Hair Studio premium men's salon"
            className="hero-image"
          />
          <div className="hero-overlay" />
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.4 }}
            variants={fadeUp}
            className="royal-container hero-content"
          >
            <p className="hero-kicker">
              Men's Salon in Gurgaon, India
            </p>
            <h1 className="hero-title">
              Premium Grooming.
              <br />
              Timeless Confidence.
            </h1>
            <p className="hero-subtitle">
              Royal Hair Studio delivers modern haircuts, precise beard work, and relaxing
              hair spa treatments in a refined, welcoming space.
            </p>
            <div className="hero-actions">
              <Button asChild className="cta-primary" onClick={onBookingClick}>
                <a href="#contact">Book Appointment</a>
              </Button>
              <Button asChild variant="outline" className="cta-secondary">
                <a href="tel:+919876543210">Call Now</a>
              </Button>
            </div>
          </motion.div>
        </section>
      </main>

      <footer className="royal-footer">
        <div className="royal-container footer-layout">
          <div>
            <h3 className="footer-brand">Royal Hair Studio</h3>
            <p className="footer-copy">
              Your trusted men's grooming destination in Gurgaon.
            </p>
          </div>
        </div>
      </footer>

      <Toaster position="top-right" />
    </div>
  );
}
